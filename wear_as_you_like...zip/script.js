function startDesign() {
  alert("Welcome to WEAR AS YOU LIKE! Let's start designing.");
  // Future: Redirect to design studio page
}