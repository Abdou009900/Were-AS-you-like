ارفع مجلد 'wear-as-you-like' بالكامل إلى استضافتك داخل مجلد htdocs أو public_html حسب الشركة.
ابدأ من index.html.
يمكنك تعديل التصاميم بسهولة من خلال الملفات في css/js/html.